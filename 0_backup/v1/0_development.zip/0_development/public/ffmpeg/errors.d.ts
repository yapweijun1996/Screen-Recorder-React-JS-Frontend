export declare const ERROR_UNKNOWN_MESSAGE_TYPE: Error;
export declare const ERROR_NOT_LOADED: Error;
export declare const ERROR_TERMINATED: Error;
export declare const ERROR_IMPORT_FAILURE: Error;
