# ScreenClip Pro (Source)
This directory contains the Vite/React source that powers ScreenClip Pro. Built and maintained by **yapweijun1996**. See the top-level `README.md` for the project overview, setup commands, and notes about FFmpeg and shared array buffers.
